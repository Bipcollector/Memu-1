#include <iostream>
#include <fstream>
#include <chrono>
#include <thread>
#include <conio.h>
#include "Bus.h"
#include "CPU65C02.h"

bool loadROM(const std::string& filename, Bus& bus) {
    std::ifstream file(filename, std::ios::binary | std::ios::ate);
    if (!file.is_open()) {
        std::cerr << "[ERREUR] Impossible d'ouvrir : " << filename << "\n";
        return false;
    }
    std::streamsize size = file.tellg();
    file.seekg(0, std::ios::beg);

    if (size == 32768) {
        std::cout << "[INFO] ROM 32Ko detectee (dump 28C256). Chargement de la 2eme moitie...\n";
        file.seekg(16384);
        file.read(reinterpret_cast<char*>(bus.getROM().data()), 16384);
    } else if (size > 0 && size <= 16384) {
        std::cout << "[INFO] ROM " << size << " octets. Chargement direct...\n";
        file.read(reinterpret_cast<char*>(bus.getROM().data()), size);
    } else {
        std::cerr << "[ERREUR] Taille ROM inattendue : " << size << " octets.\n";
        return false;
    }
    std::cout << "[OK] ROM chargee.\n";
    return true;
}

int main(int argc, char* argv[]) {
    std::cout << "========================================\n";
    std::cout << "  MEMO-1 Emulator (W65C02 @ 1MHz)\n";
    std::cout << "  Terminal Minitel Emule\n";
    std::cout << "========================================\n\n";
    std::cout.flush();

    Bus      bus;
    CPU65C02 cpu;
    cpu.connectBus(&bus);

    std::string romFile = (argc > 1) ? argv[1] : "memo1_rom.bin";
    if (!loadROM(romFile, bus)) {
        std::cerr << "\nAppuyez sur Entree pour quitter...";
        std::cin.get();
        return 1;
    }

    cpu.reset();

    std::cout << "[SYSTEME] Boucle d'emulation active. (Ctrl+C pour quitter)\n\n";
    std::cout.flush();

    // Timing : 1 MHz -> 1000 cycles par milliseconde
    const int  CYCLES_PAR_MS = 1000;
    const auto DUREE_MS      = std::chrono::microseconds(1000);

    while (true) {
        auto t0 = std::chrono::high_resolution_clock::now();

        // --- Lecture clavier non-bloquante ---
        while (_kbhit()) {
            int ch = _getch();
            if (ch == 0 || ch == 0xE0) {
                if (_kbhit()) _getch();
            } else {
                bus.getACIA().injectByte(static_cast<uint8_t>(ch));
            }
        }

        // --- Exécution CPU : 1000 cycles ---
        for (int i = 0; i < CYCLES_PAR_MS; ++i) {
            cpu.irq_line = bus.getACIA().hasInterrupt();
            cpu.clock();
        }

        // --- Vidage du buffer d'affichage accumulé vers la console ---
        bus.getACIA().flushDisplay();

        // --- Tick VIA (horloge timer1) ---
        bus.getVIA().tick(CYCLES_PAR_MS);

        // --- Synchronisation temps réel ---
        auto elapsed = std::chrono::high_resolution_clock::now() - t0;
        if (elapsed < DUREE_MS)
            std::this_thread::sleep_for(DUREE_MS - elapsed);
    }

    return 0;
}
