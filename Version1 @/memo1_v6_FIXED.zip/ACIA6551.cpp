#include "ACIA6551.h"
#include <iostream>

// Protocole Videotex Minitel : les séquences ESC ont des longueurs fixes
// selon le 2ème byte (identifiant de commande) :
//   ESC 0x23..0x28 -> 1 byte paramètre  (sélection jeu de caractères)
//   ESC ':'(0x3A)  -> 3 bytes total après ESC
//   ESC ';'(0x3B)  -> 4 bytes total après ESC
//   ESC 0x3C..0x3F -> 3 bytes total après ESC
//   ESC 0x40..0x7E -> commande finale seule (1 byte)

ACIA6551::ACIA6551() {
    status  = TDRE;
    command = 0x02; // IRQ RX désactivées par défaut (bit1=1)
}

// --- Filtre Videotex ---
void ACIA6551::filterVideotex(uint8_t data) {
    switch (esc_state) {

        case EscState::NORMAL:
            if (data == 0x1B) {
                esc_state = EscState::IN_ESC;
                esc_param_count  = 0;
                esc_total_params = 0;
            }
            else if (data == 0x1F) {
                // US = positionnement curseur, avaler 2 bytes (row, col)
                esc_state = EscState::IN_US;
                esc_param_count = 0;
            }
            else if (data == 0x0C) {
                // Form Feed = Clear Screen (séquence ANSI)
                display_buffer += "\033[2J\033[H";
            }
            else if (data == 0x0D) {
                display_buffer += "\r\n";
            }
            else if (data == 0x0A) {
                // LF ignoré (le CR a déjà sauté la ligne)
            }
            else if (data == 0x08) {
                display_buffer += '\b';
            }
            else if (data >= 0x20 && data < 0x7F) {
                display_buffer += static_cast<char>(data);
            }
            // Tous les autres codes < 0x20 ignorés silencieusement
            break;

        case EscState::IN_ESC:
            if (esc_param_count == 0) {
                // Premier byte après ESC : détermine la longueur
                if      (data >= 0x23 && data <= 0x28)                               esc_total_params = 1;
                else if (data == 0x3A || data == 0x3C ||
                         data == 0x3D || data == 0x3E || data == 0x3F)               esc_total_params = 3;
                else if (data == 0x3B)                                                esc_total_params = 4;
                else if (data >= 0x40 && data <= 0x7E) { esc_state = EscState::NORMAL; return; }
                else                                                                  esc_total_params = 99;
                esc_param_count = 1;
            } else {
                esc_param_count++;
                if (esc_total_params != 99) {
                    if (esc_param_count >= esc_total_params)
                        esc_state = EscState::NORMAL;
                } else {
                    // Fallback : attend une lettre >= 0x40
                    if (data >= 0x40 && data <= 0x7E)
                        esc_state = EscState::NORMAL;
                }
            }
            break;

        case EscState::IN_US:
            if (++esc_param_count >= 2)
                esc_state = EscState::NORMAL;
            break;
    }
}

// --- Flush du buffer d'affichage (appelé depuis main() une fois par ms) ---
void ACIA6551::flushDisplay() {
    if (!display_buffer.empty()) {
        std::cout << display_buffer;
        std::cout.flush();
        display_buffer.clear();
    }
}

// --- Lecture registres ---
uint8_t ACIA6551::read(uint8_t reg) {
    switch (reg & 0x03) {
        case 0x00: // Data RX
            if (!keyboard_buffer.empty()) {
                rx_data = keyboard_buffer.front();
                keyboard_buffer.pop();
            }
            status = keyboard_buffer.empty() ? (status & ~RDRF) : (status | RDRF);
            return rx_data;

        case 0x01: // Status — TDRE toujours 1 (TX instantané)
            return status | TDRE;

        case 0x02: return command;
        case 0x03: return control;
        default:   return 0x00;
    }
}

// --- Écriture registres ---
void ACIA6551::write(uint8_t reg, uint8_t data) {
    switch (reg & 0x03) {
        case 0x00: // Data TX — on filtre et accumule, sans flush immédiat
            tx_data = data;
            filterVideotex(data);
            // PAS de flush ici : flushDisplay() est appelé depuis main()
            // toutes les ~1ms (= 1000 cycles), ce qui est largement suffisant.
            break;

        case 0x01: // Reset
            status &= ~(PE | FE | OVRN);
            break;

        case 0x02: // Command
            command = data;
            break;

        case 0x03: // Control
            control = data;
            break;
    }
}
