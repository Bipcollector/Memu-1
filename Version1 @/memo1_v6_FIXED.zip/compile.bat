@echo off
echo Nettoyage des anciens fichiers...
del memo1.exe 2>nul
del *.o 2>nul
del *.obj 2>nul

echo Compilation en cours (tous les fichiers)...
g++ -std=c++17 -O2 -o memo1.exe ^
    main.cpp ^
    ACIA6551.cpp ^
    VIA6522.cpp ^
    Bus.cpp ^
    -static-libgcc -static-libstdc++

if %ERRORLEVEL% == 0 (
    echo =================================================
    echo COMPILATION REUSSIE !
    echo =================================================
    memo1.exe
) else (
    echo ERREUR DE COMPILATION.
    pause
)
