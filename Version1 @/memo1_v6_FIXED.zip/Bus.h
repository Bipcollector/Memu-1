#pragma once
#include <cstdint>
#include <array>
#include "ACIA6551.h"
#include "VIA6522.h" // Sera remplacé par le vrai code à l'étape 4

class Bus {
public:
    Bus();
    ~Bus() = default;

    // Lecture et écriture sur le bus d'adresses 16 bits
    [[nodiscard]] uint8_t read(uint16_t address);
    void write(uint16_t address, uint8_t data);

    // Accès direct aux périphériques (nécessaire pour la boucle principale)
    ACIA6551& getACIA() { return acia; }
    VIA6522& getVIA() { return via; }

    // Accès direct à la ROM pour le chargeur de fichier (Étape 5)
    std::array<uint8_t, 16384>& getROM() { return rom; }

private:
    // Mémoires principales
    std::array<uint8_t, 32768> ram; // 0x0000 - 0x7FFF (32 Ko - HM62256)
    std::array<uint8_t, 16384> rom; // 0xC000 - 0xFFFF (16 Ko - 28C256)

    // Périphériques
    ACIA6551 acia; // 0x9000 - 0x9FFF
    VIA6522 via;   // 0x8000 - 0x8FFF
};