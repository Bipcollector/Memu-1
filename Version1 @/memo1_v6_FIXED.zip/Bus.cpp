#include "Bus.h"
#include <algorithm>

Bus::Bus() {
    ram.fill(0x00);
    rom.fill(0x00);
}

uint8_t Bus::read(uint16_t address) {
    if (address <= 0x7FFF) return ram[address];
    else if (address <= 0x8FFF) return via.read(address & 0x0F);
    else if (address <= 0x9FFF) return acia.read(address & 0x03);
    else if (address <= 0xBFFF) return (address >> 8) & 0xFF;
    else return rom[address - 0xC000];
}

void Bus::write(uint16_t address, uint8_t data) {
    if (address <= 0x7FFF) ram[address] = data;
    else if (address <= 0x8FFF) via.write(address & 0x0F, data);
    else if (address <= 0x9FFF) acia.write(address & 0x03, data);
}