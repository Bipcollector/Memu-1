#pragma once
#include <cstdint>
#include <queue>
#include <string>

class ACIA6551 {
public:
    ACIA6551();
    ~ACIA6551() = default;

    uint8_t read(uint8_t reg);
    void write(uint8_t reg, uint8_t data);

    // Appelé depuis main() une fois par tranche — vide le buffer d'affichage
    void flushDisplay();

    [[nodiscard]] bool hasInterrupt() const {
        return (status & RDRF) && !(command & 0x02);
    }

    void injectByte(uint8_t b) {
        keyboard_buffer.push(b);
        status |= RDRF;
    }

private:
    uint8_t rx_data = 0x00;
    uint8_t tx_data = 0x00;
    uint8_t status  = 0x00;
    uint8_t command = 0x00;
    uint8_t control = 0x00;

    std::queue<uint8_t> keyboard_buffer;

    // Buffer d'affichage : les chars sont accumulés ici pendant l'émulation
    // et écrits d'un coup dans flushDisplay() — pas de flush à chaque cycle CPU
    std::string display_buffer;

    // Automate de filtrage des séquences Videotex Minitel
    enum class EscState : uint8_t { NORMAL, IN_ESC, IN_US };
    EscState esc_state        = EscState::NORMAL;
    uint8_t  esc_param_count  = 0;
    uint8_t  esc_total_params = 0;

    void filterVideotex(uint8_t data);

    enum StatusFlags : uint8_t {
        PE   = 0x01, FE   = 0x02, OVRN = 0x04, RDRF = 0x08,
        TDRE = 0x10, DCD  = 0x20, CTS  = 0x40, IRQ  = 0x80
    };
};
