#pragma once
#include <windows.h>
#include <mmsystem.h>
#include <cstdint>
#include <vector>

// ============================================================
//  AudioEngine : reproduit le buzzer du Memo-1 (broche PB7 du VIA)
// ============================================================
//  Sur le vrai matériel, le son n'est produit par aucune puce sonore
//  dédiée : la ROM fait clignoter directement la broche PB7 du VIA
//  (via une boucle de délai calibrée) pour piloter un buzzer piezo
//  connecté dessus. C'est du "bit-banging" pur — le son EST la suite
//  d'états haut/bas de cette broche dans le temps.
//
//  Pour reproduire ça fidèlement, on échantillonne l'état de PB7
//  (VIA6522::isBuzzerOn()) au rythme d'un vrai taux d'échantillonnage
//  audio (44100 Hz), synchronisé sur les cycles CPU réellement
//  écoulés (le CPU tourne à 1 MHz émulé). Chaque échantillon vaut
//  simplement +AMPLITUDE ou -AMPLITUDE selon l'état de la broche à
//  cet instant précis : on capture exactement le signal carré que la
//  ROM génère, sans avoir à deviner une fréquence a priori.
class AudioEngine {
public:
    AudioEngine();
    ~AudioEngine();

    // Ouvre le périphérique audio Windows. Retourne false si aucune
    // carte son n'est disponible (l'émulateur continue sans son).
    bool init();
    void shutdown();

    // A appeler une fois par cycle CPU écoulé, avec l'état courant de
    // la broche PB7. Accumule des échantillons audio et les envoie à
    // la carte son par blocs dès qu'un buffer est plein.
    void tick(bool buzzerHigh);

private:
    static constexpr int SAMPLE_RATE        = 44100;
    static constexpr int CPU_HZ             = 1000000; // 1 MHz émulé
    static constexpr int SAMPLES_PER_BUFFER = 512;
    static constexpr int NUM_BUFFERS        = 4;
    static constexpr int16_t AMPLITUDE      = 6000;     // volume modéré

    struct Buffer {
        std::vector<int16_t> data;
        WAVEHDR header{};
    };

    HWAVEOUT hWaveOut = nullptr;
    Buffer   buffers[NUM_BUFFERS];
    bool     submitted[NUM_BUFFERS] = {};
    int      currentBuffer = 0;
    int      fillPos = 0;
    bool     initialized = false;

    // Conversion cycles CPU écoulés -> échantillons audio à produire.
    double cycleAccumulator = 0.0;
    static constexpr double CYCLES_PER_SAMPLE =
        static_cast<double>(CPU_HZ) / static_cast<double>(SAMPLE_RATE);

    void submitBuffer(int idx);
    void waitForBufferFree(int idx);
};
