#include "AudioEngine.h"

AudioEngine::AudioEngine() {
    for (auto& buf : buffers) {
        buf.data.resize(SAMPLES_PER_BUFFER, 0);
    }
}

AudioEngine::~AudioEngine() {
    shutdown();
}

bool AudioEngine::init() {
    WAVEFORMATEX wfx{};
    wfx.wFormatTag      = WAVE_FORMAT_PCM;
    wfx.nChannels       = 1;
    wfx.nSamplesPerSec  = SAMPLE_RATE;
    wfx.wBitsPerSample  = 16;
    wfx.nBlockAlign     = wfx.nChannels * wfx.wBitsPerSample / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;
    wfx.cbSize          = 0;

    MMRESULT res = waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    if (res != MMSYSERR_NOERROR) {
        hWaveOut = nullptr;
        return false;
    }

    for (int i = 0; i < NUM_BUFFERS; i++) {
        ZeroMemory(&buffers[i].header, sizeof(WAVEHDR));
        buffers[i].header.lpData         = reinterpret_cast<LPSTR>(buffers[i].data.data());
        buffers[i].header.dwBufferLength = static_cast<DWORD>(buffers[i].data.size() * sizeof(int16_t));
        waveOutPrepareHeader(hWaveOut, &buffers[i].header, sizeof(WAVEHDR));
        submitted[i] = false;
    }

    initialized      = true;
    currentBuffer    = 0;
    fillPos          = 0;
    cycleAccumulator = 0.0;
    return true;
}

void AudioEngine::shutdown() {
    if (!initialized) return;
    initialized = false;
    if (hWaveOut) {
        waveOutReset(hWaveOut);
        for (int i = 0; i < NUM_BUFFERS; i++) {
            waveOutUnprepareHeader(hWaveOut, &buffers[i].header, sizeof(WAVEHDR));
        }
        waveOutClose(hWaveOut);
        hWaveOut = nullptr;
    }
}

void AudioEngine::submitBuffer(int idx) {
    if (!hWaveOut) return;
    waveOutWrite(hWaveOut, &buffers[idx].header, sizeof(WAVEHDR));
    submitted[idx] = true;
}

void AudioEngine::waitForBufferFree(int idx) {
    // Un buffer jamais soumis n'a pas besoin qu'on l'attende : il est
    // déjà libre par définition (juste initialisé à zéro).
    if (!hWaveOut || !submitted[idx]) return;

    // Attend que la carte son ait fini de jouer ce buffer (drapeau
    // WHDR_DONE posé par Windows) avant de le réutiliser, pour ne
    // jamais écraser des données en cours de lecture. Le nombre
    // d'itérations est borné par sécurité pour ne jamais bloquer
    // indéfiniment si quelque chose tourne mal côté pilote audio.
    int guard = 0;
    while (!(buffers[idx].header.dwFlags & WHDR_DONE) && guard < 5000) {
        Sleep(0);
        guard++;
    }
}

void AudioEngine::tick(bool buzzerHigh) {
    if (!initialized) return;

    cycleAccumulator += 1.0;  // un cycle CPU vient de s'écouler
    while (cycleAccumulator >= CYCLES_PER_SAMPLE) {
        cycleAccumulator -= CYCLES_PER_SAMPLE;

        buffers[currentBuffer].data[fillPos++] =
            buzzerHigh ? AMPLITUDE : static_cast<int16_t>(-AMPLITUDE);

        if (fillPos >= SAMPLES_PER_BUFFER) {
            submitBuffer(currentBuffer);
            currentBuffer = (currentBuffer + 1) % NUM_BUFFERS;
            fillPos = 0;
            waitForBufferFree(currentBuffer);
        }
    }
}
