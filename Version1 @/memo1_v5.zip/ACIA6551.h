#pragma once
#include <cstdint>
#include <queue>

class ACIA6551 {
public:
    ACIA6551();
    ~ACIA6551() = default;

    uint8_t read(uint8_t reg);
    void write(uint8_t reg, uint8_t data);
    void pollKeyboard();

    [[nodiscard]] bool hasInterrupt() const {
        // IRQ si RDRF=1 ET IRQ réception activées (bit1 du Command = 0)
        return (status & RDRF) && !(command & 0x02);
    }

    void injectByte(uint8_t b) {
        keyboard_buffer.push(b);
        status |= RDRF;
    }

private:
    uint8_t rx_data = 0x00;
    uint8_t tx_data = 0x00;
    uint8_t status  = 0x00;
    uint8_t command = 0x00;
    uint8_t control = 0x00;

    std::queue<uint8_t> keyboard_buffer;

    // Automate de filtrage des séquences Videotex Minitel
    enum class EscState : uint8_t {
        NORMAL,   // affichage normal
        IN_ESC,   // à l'intérieur d'une séquence ESC
        IN_US,    // commande de positionnement curseur (1F row col)
    };
    EscState esc_state       = EscState::NORMAL;
    uint8_t  esc_param_count = 0;  // nombre de bytes lus dans la séquence courante
    uint8_t  esc_total_params = 0; // nombre total de bytes à avaler après ESC

    enum StatusFlags : uint8_t {
        PE   = 0x01,
        FE   = 0x02,
        OVRN = 0x04,
        RDRF = 0x08,
        TDRE = 0x10,
        DCD  = 0x20,
        CTS  = 0x40,
        IRQ  = 0x80
    };
};
