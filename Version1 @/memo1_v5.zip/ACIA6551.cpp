#include "ACIA6551.h"
#include <iostream>

// Protocole Videotex Minitel (Télétel) :
//
// Les séquences de contrôle ont la forme ESC + N bytes.
// La longueur après ESC dépend du 2ème byte (identifiant de commande) :
//
//   ESC 0x23..0x28 -> 1 byte de paramètre  (sélection jeu de caractères)
//   ESC 0x3A ':'   -> 3 bytes de paramètre (ex: ':' 'k' 'v', ':' 'j' 'C')
//   ESC 0x3B ';'   -> 4 bytes de paramètre (ex: ';' '`' 'Z' 'Q', ';' 'j' 'Y' 'A')
//   ESC 0x3C..'@'  -> 3 bytes de paramètre
//   ESC 0x40..0x7E -> 1 byte (commande mono-paramètre)
//
// Codes de contrôle Minitel standalone (< 0x20) :
//   0x0C = CLS (Form Feed) = effacer l'écran
//   0x0D = CR
//   0x0A = LF
//   0x08 = BS
//   0x1F = US  (Unit Separator) suivi de 2 bytes row/col
//   0x14 = CON (contrôle curseur) -> 1 byte standalone, ignoré

ACIA6551::ACIA6551() {
    status  = TDRE;
    command = 0x02; // IRQ RX désactivées par défaut
}

void ACIA6551::pollKeyboard() {
    if (!keyboard_buffer.empty()) status |= RDRF;
    else                          status &= ~RDRF;
}

uint8_t ACIA6551::read(uint8_t reg) {
    switch (reg & 0x03) {
        case 0x00:
            if (!keyboard_buffer.empty()) {
                rx_data = keyboard_buffer.front();
                keyboard_buffer.pop();
            }
            status = keyboard_buffer.empty() ? (status & ~RDRF) : (status | RDRF);
            return rx_data;

        case 0x01:
            return status | TDRE; // TDRE toujours 1

        case 0x02: return command;
        case 0x03: return control;
        default:   return 0x00;
    }
}

void ACIA6551::write(uint8_t reg, uint8_t data) {
    switch (reg & 0x03) {

        case 0x00: {
            tx_data = data;

            switch (esc_state) {

                case EscState::NORMAL:
                    if (data == 0x1B) {
                        // Début de séquence ESC Videotex
                        esc_state = EscState::IN_ESC;
                        esc_param_count = 0;
                        esc_total_params = 0;
                    }
                    else if (data == 0x1F) {
                        // US = positionnement curseur, suivi de 2 bytes row+col
                        esc_state = EscState::IN_US;
                        esc_param_count = 0;
                    }
                    else if (data == 0x0C) {
                        // Form Feed = Clear Screen
                        // Séquence ANSI standard pour effacer et repositionner
                        std::cout << "\033[2J\033[H";
                        std::cout.flush();
                    }
                    else if (data == 0x0D) {
                        std::cout << "\r\n";
                        std::cout.flush();
                    }
                    else if (data == 0x0A) {
                        // LF ignoré (le CR l'a géré)
                    }
                    else if (data == 0x08) {
                        std::cout << '\b';
                        std::cout.flush();
                    }
                    else if (data >= 0x20 && data < 0x7F) {
                        // Caractère ASCII imprimable
                        std::cout << static_cast<char>(data);
                        std::cout.flush();
                    }
                    // Tous les autres codes < 0x20 sont ignorés silencieusement
                    break;

                case EscState::IN_ESC:
                    // Premier byte après ESC : détermine la longueur de la séquence
                    if (esc_param_count == 0) {
                        // Calculer combien de bytes supplémentaires on doit avaler
                        if (data >= 0x23 && data <= 0x28) {
                            esc_total_params = 1; // séquence courte
                        } else if (data == 0x3A || data == 0x3C ||
                                   data == 0x3D || data == 0x3E || data == 0x3F) {
                            esc_total_params = 3; // séquences à 3 params dont le 1er déjà lu
                        } else if (data == 0x3B) {
                            esc_total_params = 4; // séquences à 4 params dont le 1er déjà lu
                        } else if (data >= 0x40 && data <= 0x7E) {
                            // Commande finale : séquence terminée avec ce seul byte
                            esc_state = EscState::NORMAL;
                            return;
                        } else {
                            // Inconnu : on avale jusqu'à une lettre >= 0x40
                            esc_total_params = 99;
                        }
                        esc_param_count = 1; // on a lu le 1er byte identifiant
                    } else {
                        // Bytes suivants : paramètres
                        esc_param_count++;
                        if (esc_total_params != 99) {
                            if (esc_param_count >= esc_total_params) {
                                esc_state = EscState::NORMAL;
                            }
                        } else {
                            // Mode fallback : on attend une lettre >= 0x40
                            if (data >= 0x40 && data <= 0x7E) {
                                esc_state = EscState::NORMAL;
                            }
                        }
                    }
                    break;

                case EscState::IN_US:
                    // US suivi de 2 bytes (row, col) qu'on ignore
                    if (++esc_param_count >= 2) {
                        esc_state = EscState::NORMAL;
                    }
                    break;
            }

            // PAS DE LOOPBACK.
            break;
        }

        case 0x01:
            // Reset : efface les flags d'erreur
            status &= ~(PE | FE | OVRN);
            break;

        case 0x02:
            command = data;
            break;

        case 0x03:
            control = data;
            break;
    }
}
