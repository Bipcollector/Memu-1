#include "ACIA6551.h"
#include <iostream>

// Note: on n'inclut plus <conio.h> ici.
// La lecture clavier est gérée dans main.cpp de façon non-bloquante
// et injectée via injectByte().

ACIA6551::ACIA6551() {
    // Le 6551 démarre avec TDRE=1 (transmetteur prêt) et rien d'autre.
    // PAS de 0x06 fictif : le vrai Minitel n'envoie rien au démarrage,
    // c'est le Memo-1 qui prend l'initiative de la communication.
    status = TDRE;
    command = 0x02; // bit1=1 : IRQ réception désactivées par défaut
                    // La ROM écrira dans ce registre pour les activer
}

void ACIA6551::pollKeyboard() {
    // Cette méthode n'est plus utilisée directement.
    // La lecture clavier est faite dans main.cpp via _kbhit()/_getch()
    // et les bytes sont injectés via injectByte().
    // On met juste à jour le flag RDRF.
    if (!keyboard_buffer.empty()) {
        status |= RDRF;
    } else {
        status &= ~RDRF;
    }
}

uint8_t ACIA6551::read(uint8_t reg) {
    switch (reg & 0x03) {

        case 0x00: // Registre Data (RX)
            // La lecture du registre data efface RDRF
            if (!keyboard_buffer.empty()) {
                uint8_t ch = keyboard_buffer.front();
                keyboard_buffer.pop();
                rx_data = ch;
            }
            // Mettre à jour RDRF après la lecture
            if (keyboard_buffer.empty()) {
                status &= ~RDRF;
            } else {
                status |= RDRF;
            }
            return rx_data;

        case 0x01: // Registre Status
            // TDRE (bit4) est TOUJOURS à 1 dans notre émulateur :
            // le transmetteur est instantanément disponible (pas de vraie UART)
            return status | TDRE;

        case 0x02: // Registre Command (lecture)
            return command;

        case 0x03: // Registre Control (lecture)
            return control;

        default:
            return 0x00;
    }
}

void ACIA6551::write(uint8_t reg, uint8_t data) {
    switch (reg & 0x03) {

        case 0x00: // Registre Data (TX) - émission d'un caractère
            tx_data = data;

            // Affichage dans la console hôte.
            // On filtre les codes de contrôle Videotex/ANSI qu'on ne sait
            // pas interpréter pour ne pas polluer le terminal Windows,
            // mais on laisse passer CR, LF et les chars imprimables.
            if (data == 0x0D) {          // CR -> CRLF
                std::cout << "\r\n";
            } else if (data == 0x0A) {   // LF -> ignoré (le CR l'a déjà fait)
                // rien
            } else if (data == 0x0C) {   // FF = clear screen Minitel
                // On efface la console avec une séquence ANSI standard
                std::cout << "\033[2J\033[H";
            } else if (data >= 0x20 && data < 0x7F) { // Char imprimable ASCII
                std::cout << static_cast<char>(data);
            } else if (data == 0x1B) {   // ESC : début d'une séquence Videotex
                // On ignore silencieusement : le Minitel réel l'interpréterait
                // pour déplacer le curseur, changer la couleur, etc.
                // Pour l'émulateur terminal, on pourrait plus tard mapper ces
                // séquences vers des séquences ANSI.
            }
            // Tous les autres codes de contrôle (<0x20 sauf CR/LF) sont ignorés.

            std::cout << std::flush;

            // IMPORTANT : PAS DE LOOPBACK !
            // Sur le vrai hardware, les bytes TX partent vers le Minitel via RS-232.
            // Le Minitel les affiche sur son écran. Il ne les renvoie PAS.
            // Notre émulateur envoie vers stdout à la place.
            // On ne remet JAMAIS les bytes TX dans keyboard_buffer.
            break;

        case 0x01: // Registre Reset (écriture) - sur le 6551, écrire ici reset le chip
            // On remet juste les flags d'erreur à zéro
            status &= ~(PE | FE | OVRN);
            break;

        case 0x02: // Registre Command
            command = data;
            // bit1 = 0 -> IRQ réception activées
            // bit1 = 1 -> IRQ réception désactivées
            // La ROM écrira ici pour activer les IRQ une fois prête
            break;

        case 0x03: // Registre Control (vitesse, format)
            control = data;
            // On ne simule pas vraiment la vitesse, mais on stocke la valeur
            // pour que la ROM soit satisfaite de ses lectures.
            break;
    }
}
