#pragma once
#include <cstdint>
#include <queue>

class ACIA6551 {
public:
    ACIA6551();
    ~ACIA6551() = default;

    uint8_t read(uint8_t reg);
    void write(uint8_t reg, uint8_t data);
    void pollKeyboard();

    // Retourne true si l'ACIA doit déclencher une IRQ
    // L'ACIA 6551 génère une IRQ quand un byte est reçu (RDRF=1)
    // et que les IRQ réception sont activées (bit DTR du registre Command)
    [[nodiscard]] bool hasInterrupt() const {
        // Bit 1 du registre Command contrôle les IRQ réception sur le 6551
        // Si RDRF est levé et que les IRQ ne sont pas masquées => IRQ
        return (status & RDRF) && !(command & 0x02);
    }

    // Injecter un byte depuis le "Minitel" (clavier hôte)
    void injectByte(uint8_t b) {
        keyboard_buffer.push(b);
        status |= RDRF;
    }

private:
    uint8_t rx_data = 0x00;
    uint8_t tx_data = 0x00;
    uint8_t status  = 0x00;
    uint8_t command = 0x00; // bit1=1 -> IRQ réception désactivée
    uint8_t control = 0x00;

    std::queue<uint8_t> keyboard_buffer;

    // Bits du registre Status du W65C51 / MOS 6551
    enum StatusFlags : uint8_t {
        PE   = 0x01, // Bit 0 : Parity Error
        FE   = 0x02, // Bit 1 : Framing Error
        OVRN = 0x04, // Bit 2 : Overrun Error
        RDRF = 0x08, // Bit 3 : Receive Data Register Full
        TDRE = 0x10, // Bit 4 : Transmit Data Register Empty
        DCD  = 0x20, // Bit 5 : Data Carrier Detect
        CTS  = 0x40, // Bit 6 : Clear To Send
        IRQ  = 0x80  // Bit 7 : Interrupt Request (actif bas sur le vrai chip)
    };
};
