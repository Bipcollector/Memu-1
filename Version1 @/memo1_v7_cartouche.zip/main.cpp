#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include <thread>
#include <conio.h>
#include <windows.h>
#include "Bus.h"
#include "CPU65C02.h"

// ============================================================
//  Chargement de la ROM interne
// ============================================================
bool loadROM(const std::string& filename, Bus& bus) {
    std::ifstream file(filename, std::ios::binary | std::ios::ate);
    if (!file.is_open()) {
        std::cerr << "[ERREUR] Impossible d'ouvrir : " << filename << "\n";
        return false;
    }
    std::streamsize size = file.tellg();
    file.seekg(0, std::ios::beg);

    if (size == 32768) {
        std::cout << "[INFO] ROM 32Ko detectee (dump 28C256). Chargement de la 2eme moitie...\n";
        file.seekg(16384);
        file.read(reinterpret_cast<char*>(bus.getROM().data()), 16384);
    } else if (size > 0 && size <= 16384) {
        std::cout << "[INFO] ROM " << size << " octets. Chargement direct...\n";
        file.read(reinterpret_cast<char*>(bus.getROM().data()), size);
    } else {
        std::cerr << "[ERREUR] Taille ROM inattendue : " << size << " octets.\n";
        return false;
    }
    std::cout << "[OK] ROM interne chargee.\n";
    return true;
}

// ============================================================
//  Recherche de la ROM interne dans le même dossier que l'exe
// ============================================================
std::string findROM() {
    char path[MAX_PATH];
    GetModuleFileNameA(NULL, path, MAX_PATH);
    std::string exe(path);
    size_t pos = exe.find_last_of("\\/");
    std::string dir = (pos != std::string::npos) ? exe.substr(0, pos + 1) : "";
    return dir + "memo1_rom.bin";
}

// ============================================================
//  Boucle d'émulation principale
// ============================================================
void runEmulator(Bus& bus, CPU65C02& cpu) {
    const int  CYCLES_PAR_MS = 1000;           // 1 MHz = 1000 cycles/ms
    const auto DUREE_MS      = std::chrono::microseconds(1000);

    while (true) {
        auto t0 = std::chrono::high_resolution_clock::now();

        // Lecture clavier non-bloquante
        while (_kbhit()) {
            int ch = _getch();
            if (ch == 0 || ch == 0xE0) {
                if (_kbhit()) _getch(); // touche étendue : on avale le 2ème byte
            } else {
                bus.getACIA().injectByte(static_cast<uint8_t>(ch));
            }
        }

        // Exécution CPU
        for (int i = 0; i < CYCLES_PAR_MS; ++i) {
            cpu.irq_line = bus.getACIA().hasInterrupt();
            cpu.clock();
        }

        // Affichage
        bus.getACIA().flushDisplay();

        // Tick VIA
        bus.getVIA().tick(CYCLES_PAR_MS);

        // Synchronisation temps réel
        auto elapsed = std::chrono::high_resolution_clock::now() - t0;
        if (elapsed < DUREE_MS)
            std::this_thread::sleep_for(DUREE_MS - elapsed);
    }
}

// ============================================================
//  Point d'entrée
// ============================================================
int main(int argc, char* argv[]) {
    // Titre de la fenêtre console Windows
    SetConsoleTitleA("MEMO-1 Emulator");

    std::cout << "========================================\n";
    std::cout << "  MEMO-1 Emulator (W65C02 @ 1MHz)\n";
    std::cout << "  Terminal Minitel Emule\n";
    std::cout << "========================================\n\n";
    std::cout.flush();

    // ---- Initialisation matérielle ----
    Bus      bus;
    CPU65C02 cpu;
    cpu.connectBus(&bus);

    // ---- Chargement ROM interne ----
    std::string romPath = findROM();
    if (!loadROM(romPath, bus)) {
        // Essai depuis le répertoire courant
        if (!loadROM("memo1_rom.bin", bus)) {
            std::cerr << "\n[ERREUR] memo1_rom.bin introuvable.\n";
            std::cerr << "Placez memo1_rom.bin dans le meme dossier que memo1.exe\n";
            std::cerr << "Appuyez sur Entree pour quitter...";
            std::cin.get();
            return 1;
        }
    }

    // ---- Chargement cartouche (glisser-déposer) ----
    // Quand l'utilisateur fait un drag & drop d'un .bin sur l'exe,
    // Windows passe le chemin du fichier en argv[1].
    if (argc >= 2) {
        std::string cartPath(argv[1]);

        // Vérifier l'extension .bin (insensible à la casse)
        bool isBin = false;
        if (cartPath.size() >= 4) {
            std::string ext = cartPath.substr(cartPath.size() - 4);
            for (auto& c : ext) c = static_cast<char>(tolower(c));
            isBin = (ext == ".bin");
        }

        if (!isBin) {
            std::cerr << "[AVERTISSEMENT] Le fichier \"" << cartPath
                      << "\" n'a pas l'extension .bin. Slot cartouche vide.\n\n";
        } else if (!bus.loadCartridge(cartPath)) {
            std::cerr << "[AVERTISSEMENT] Impossible de charger la cartouche : "
                      << cartPath << "\n"
                      << "  (le fichier doit faire au maximum 8 Ko)\n\n";
        } else {
            std::string name = bus.cartridgeName();
            std::cout << "[OK] Cartouche chargee : \"" << name << "\"\n";
            std::cout << "     Chemin : " << cartPath << "\n\n";
        }
    }

    // ---- Informations de démarrage ----
    if (bus.hasCartridge()) {
        std::cout << "[MEMO-1] Cartouche connectee -> option '4' disponible dans le menu.\n";
    } else {
        std::cout << "[MEMO-1] Aucune cartouche. Glissez un .bin de 8Ko max sur memo1.exe\n";
        std::cout << "         pour simuler une cartouche connectee au slot d'extension.\n";
    }
    std::cout << "\n[SYSTEME] Boucle d'emulation active. (Ctrl+C pour quitter)\n\n";
    std::cout.flush();

    // ---- Reset CPU et démarrage ----
    cpu.reset();

    // ---- Boucle principale ----
    runEmulator(bus, cpu);

    return 0;
}
