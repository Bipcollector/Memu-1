@echo off
echo Nettoyage...
del memo1.exe 2>nul
del *.o 2>nul
del *.obj 2>nul

echo Compilation en cours...
g++ -std=c++17 -O2 -o memo1.exe ^
    main.cpp ^
    ACIA6551.cpp ^
    VIA6522.cpp ^
    Bus.cpp ^
    -static-libgcc -static-libstdc++ -static

if %ERRORLEVEL% == 0 (
    echo ================================================
    echo  COMPILATION REUSSIE !
    echo ================================================
    echo.
    echo Usage :
    echo   memo1.exe               (sans cartouche)
    echo   memo1.exe ma_rom.bin    (avec cartouche)
    echo   Glisser-deposer un .bin sur memo1.exe
    echo.
    echo Lancement...
    memo1.exe %1
) else (
    echo ERREUR DE COMPILATION.
    pause
)
