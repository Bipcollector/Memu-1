@echo off
echo Suppression de l'ancien executable...
del memo1.exe 2>nul

echo Compilation en cours...
g++ -std=c++17 -O2 -o memo1.exe ^
    main.cpp ^
    ACIA6551.cpp ^
    VIA6522.cpp ^
    Bus.cpp ^
    -static-libgcc -static-libstdc++

if %ERRORLEVEL% == 0 (
    echo COMPILATION REUSSIE ! Lancement du Memo-1...
    echo =================================================
    memo1.exe
) else (
    echo ERREUR DE COMPILATION.
    pause
)
