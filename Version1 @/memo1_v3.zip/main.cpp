#include <iostream>
#include <fstream>
#include <chrono>
#include <thread>
#include <iomanip>
#include <conio.h>
#include "Bus.h"
#include "CPU65C02.h"

// Charge le fichier ROM dans le bus
bool loadROM(const std::string& filename, Bus& bus) {
    std::ifstream file(filename, std::ios::binary | std::ios::ate);
    if (!file.is_open()) {
        std::cerr << "[ERREUR] Impossible d'ouvrir : " << filename << std::endl;
        return false;
    }

    std::streamsize size = file.tellg();
    file.seekg(0, std::ios::beg);

    if (size == 32768) {
        // Dump complet du 28C256 (32 Ko) : la ROM utile est dans la seconde moitie
        std::cout << "[INFO] ROM 32Ko detectee (dump 28C256). Chargement de la 2eme moitie...\n";
        file.seekg(16384);
        file.read(reinterpret_cast<char*>(bus.getROM().data()), 16384);
    } else if (size <= 16384) {
        std::cout << "[INFO] ROM " << size << " octets. Chargement direct...\n";
        file.read(reinterpret_cast<char*>(bus.getROM().data()), size);
    } else {
        std::cerr << "[ERREUR] Taille ROM inattendue : " << size << " octets.\n";
        return false;
    }

    std::cout << "[OK] ROM chargee.\n";
    return true;
}

int main(int argc, char* argv[]) {
    std::cout << "========================================\n";
    std::cout << "  MEMO-1 Emulator (W65C02 @ 1MHz)\n";
    std::cout << "  Terminal Minitel Emule\n";
    std::cout << "========================================\n\n";

    // --- Initialisation matérielle ---
    Bus bus;
    CPU65C02 cpu;
    cpu.connectBus(&bus);

    // --- Chargement ROM ---
    std::string romFile = (argc > 1) ? argv[1] : "memo1_rom.bin";
    if (!loadROM(romFile, bus)) {
        std::cerr << "\nAppuyez sur Entree pour quitter...";
        std::cin.get();
        return 1;
    }

    // --- Reset CPU ---
    // Après reset(), le CPU lit le vecteur RESET en 0xFFFC-0xFFFD
    // et place PC sur le point d'entrée de la ROM ($F3FB ici).
    // Le flag I (Interrupt Disable) est ACTIF au reset : la ROM devra
    // faire CLI elle-même pour activer les IRQ (ce qu'elle fait à $F3FF).
    cpu.reset();

    std::cout << "[SYSTEME] Boucle d'emulation active. (Ctrl+C pour quitter)\n\n";

    // --- Boucle d'émulation ---
    // On vise 1 MHz : 1 000 000 cycles/sec = 1000 cycles par milliseconde.
    const int    CYCLES_PAR_TRANCHE = 1000;
    const auto   DUREE_TRANCHE      = std::chrono::microseconds(1000); // 1ms

    while (true) {
        auto t_debut = std::chrono::high_resolution_clock::now();

        // --- Lecture clavier non-bloquante ---
        // On lit TOUTES les touches disponibles et on les injecte dans l'ACIA.
        // _kbhit() et _getch() sont Windows-only (conio.h).
        // Cette lecture se fait UNE FOIS par tranche de 1000 cycles,
        // ce qui est amplement suffisant pour une saisie humaine.
        while (_kbhit()) {
            int ch = _getch();
            if (ch == 0 || ch == 0xE0) {
                // Touche étendue (flèches, F1-F12...) : on lit le 2ème octet
                // et on le jette (on pourrait mapper vers des séquences Minitel)
                if (_kbhit()) _getch();
            } else {
                // Octet ASCII normal : on l'injecte dans le buffer de réception
                // de l'ACIA. Cela lèvera RDRF et déclenchera une IRQ si la ROM
                // a activé les IRQ réception (bit1=0 du registre Command).
                bus.getACIA().injectByte(static_cast<uint8_t>(ch));
            }
        }

        // --- Exécution des cycles CPU ---
        for (int i = 0; i < CYCLES_PAR_TRANCHE; ++i) {

            // Gestion de la ligne IRQ :
            // L'ACIA lève l'IRQ quand il y a un byte reçu (RDRF=1)
            // ET que les IRQ réception sont activées dans son registre Command.
            // Le CPU ne prendra l'IRQ que si son flag I est à 0 (CLI exécuté).
            cpu.irq_line = bus.getACIA().hasInterrupt();

            cpu.clock();
        }

        // --- Tick VIA ---
        // La VIA gère le timer 1 (horloge baud rate) en arrière-plan.
        bus.getVIA().tick(CYCLES_PAR_TRANCHE);

        // --- Synchronisation temporelle ---
        // On s'assure de ne pas aller plus vite que le vrai hardware.
        auto t_fin    = std::chrono::high_resolution_clock::now();
        auto ecoule   = t_fin - t_debut;
        if (ecoule < DUREE_TRANCHE) {
            std::this_thread::sleep_for(DUREE_TRANCHE - ecoule);
        }
    }

    return 0;
}
