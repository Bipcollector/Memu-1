#include "ACIA6551.h"
#include <iostream>

// Protocole Videotex / Télétel utilisé par le Minitel :
// - ESC (0x1B) est le préfixe des séquences de contrôle
// - Une séquence Videotex = ESC + 1 ou plusieurs octets de paramètres
//   se terminant sur un octet "final" >= 0x40 (lettre majuscule ou minuscule).
//   Ex: ESC ':' 'k' 'v'  ->  3 octets après ESC, 'v' est le final
//       ESC ';' '`' 'Z' 'Q' ->  4 octets après ESC, 'Q' est le final
// - Certaines séquences Videotex démarrent sur 0x1F (US / Unit Separator)
//   qui positionne le curseur : 1F row col
// - Les autres codes de contrôle Minitel (0x01-0x1F hors ESC) sont des
//   commandes d'une seule instruction (pas de paramètres).

ACIA6551::ACIA6551() {
    // TDRE = 1 (transmetteur prêt), tout le reste à 0
    status  = TDRE;
    // bit1=1 : IRQ réception désactivées par défaut.
    // La ROM les activera en écrivant dans le registre Command.
    command = 0x02;
}

void ACIA6551::pollKeyboard() {
    // Mise à jour du bit RDRF selon le contenu du buffer.
    // La lecture clavier réelle est faite dans main.cpp via _kbhit()/_getch().
    if (!keyboard_buffer.empty()) {
        status |= RDRF;
    } else {
        status &= ~RDRF;
    }
}

uint8_t ACIA6551::read(uint8_t reg) {
    switch (reg & 0x03) {

        case 0x00: // Registre Data RX
            if (!keyboard_buffer.empty()) {
                rx_data = keyboard_buffer.front();
                keyboard_buffer.pop();
            }
            // Mettre à jour RDRF après la lecture
            if (keyboard_buffer.empty()) {
                status &= ~RDRF;
            } else {
                status |= RDRF;
            }
            return rx_data;

        case 0x01: // Registre Status
            // TDRE (bit4) toujours à 1 : le transmetteur est instantanément libre.
            return status | TDRE;

        case 0x02: return command;
        case 0x03: return control;
        default:   return 0x00;
    }
}

void ACIA6551::write(uint8_t reg, uint8_t data) {
    switch (reg & 0x03) {

        case 0x00: { // Registre Data TX — émission d'un caractère vers le Minitel
            tx_data = data;

            // --- Filtre séquences de contrôle Videotex / Minitel ---
            // Le Minitel comprend un protocole propriétaire dérivé du Videotex
            // français (Télétel). Les séquences de contrôle NE DOIVENT PAS
            // être affichées dans notre terminal texte Windows.
            //
            // Automate d'état :
            //   NORMAL  : affichage standard
            //   IN_ESC  : on a reçu ESC (0x1B), on avalise les bytes suivants
            //             jusqu'au byte "final" (>= 0x40)
            //   IN_US   : on a reçu US (0x1F), on avale les 2 bytes suivants
            //             (row, col) puis on retourne à NORMAL
            //   IN_CSI  : séquences étendues débutant par 0x9B (CSI Minitel)

            switch (esc_state) {

                case EscState::NORMAL:
                    if (data == 0x1B) {
                        // Début d'une séquence ESC Videotex : avaler les bytes suivants
                        esc_state = EscState::IN_ESC;
                    }
                    else if (data == 0x1F) {
                        // US (Unit Separator) : positionne le curseur, suivi de 2 bytes
                        esc_state = EscState::IN_US;
                        esc_param_count = 0;
                    }
                    else if (data == 0x0C) {
                        // Form Feed / Clear Screen : on vide l'écran ANSI
                        std::cout << "\033[2J\033[H" << std::flush;
                    }
                    else if (data == 0x0D) {
                        std::cout << "\r\n" << std::flush;
                    }
                    else if (data == 0x0A) {
                        // LF : ignoré (le CR l'a déjà géré)
                    }
                    else if (data == 0x08) {
                        // BS : retour arrière
                        std::cout << '\b' << std::flush;
                    }
                    else if (data == 0x07) {
                        // BEL : bip (ignoré dans notre terminal)
                    }
                    else if (data >= 0x20 && data < 0x7F) {
                        // Caractère ASCII imprimable normal
                        std::cout << static_cast<char>(data) << std::flush;
                    }
                    // Tous les autres codes de contrôle (<0x20) sont ignorés silencieusement.
                    break;

                case EscState::IN_ESC:
                    // On avale tous les bytes jusqu'au byte "final" inclus.
                    // Convention Videotex : le dernier byte d'une séquence ESC est >= 0x40.
                    // Mais attention : ':' = 0x3A, ';' = 0x3B, '<' = 0x3C sont aussi
                    // des bytes de paramètres fréquents (< 0x40) qu'on doit avaler.
                    // Le byte final est une lettre (0x41-0x7A typiquement).
                    if (data >= 0x41 && data <= 0x7A) {
                        // Byte final de la séquence ESC -> retour à NORMAL
                        esc_state = EscState::NORMAL;
                    }
                    // Sinon on reste en IN_ESC et on avale le byte
                    break;

                case EscState::IN_US:
                    // US suivi de 2 bytes (row, col) qu'on ignore
                    esc_param_count++;
                    if (esc_param_count >= 2) {
                        esc_state = EscState::NORMAL;
                    }
                    break;
            }

            // PAS DE LOOPBACK. Le Minitel réel affiche les bytes reçus
            // sur son propre écran sans les renvoyer à l'expéditeur.
            break;
        }

        case 0x01: // Reset (écriture) : efface les flags d'erreur
            status &= ~(PE | FE | OVRN);
            break;

        case 0x02: // Registre Command
            command = data;
            // bit1 = RIE (Receiver Interrupt Enable, actif bas)
            // 0 -> IRQ activées quand RDRF=1
            // 1 -> IRQ désactivées
            break;

        case 0x03: // Registre Control (baud rate, format)
            control = data;
            break;
    }
}
