#pragma once
#include <cstdint>
#include <queue>

class ACIA6551 {
public:
    ACIA6551();
    ~ACIA6551() = default;

    uint8_t read(uint8_t reg);
    void write(uint8_t reg, uint8_t data);
    void pollKeyboard();

    // L'ACIA génère une IRQ quand :
    //   - il y a un byte reçu (RDRF=1)
    //   - ET les IRQ réception sont activées (bit1 du Command = 0)
    [[nodiscard]] bool hasInterrupt() const {
        return (status & RDRF) && !(command & 0x02);
    }

    // Injecter un byte reçu depuis le clavier hôte (appelé depuis main.cpp)
    void injectByte(uint8_t b) {
        keyboard_buffer.push(b);
        status |= RDRF;
    }

private:
    uint8_t rx_data = 0x00;
    uint8_t tx_data = 0x00;
    uint8_t status  = 0x00;
    uint8_t command = 0x00;
    uint8_t control = 0x00;

    std::queue<uint8_t> keyboard_buffer;

    // Automate de filtrage des séquences de contrôle Videotex / Minitel
    enum class EscState : uint8_t {
        NORMAL,  // Affichage normal
        IN_ESC,  // À l'intérieur d'une séquence ESC, on avale les bytes
        IN_US,   // À l'intérieur d'une commande US (positionnement curseur)
    };
    EscState esc_state      = EscState::NORMAL;
    uint8_t  esc_param_count = 0;

    // Bits du registre Status du 6551
    enum StatusFlags : uint8_t {
        PE   = 0x01, // Parity Error
        FE   = 0x02, // Framing Error
        OVRN = 0x04, // Overrun Error
        RDRF = 0x08, // Receive Data Register Full
        TDRE = 0x10, // Transmit Data Register Empty
        DCD  = 0x20, // Data Carrier Detect
        CTS  = 0x40, // Clear To Send
        IRQ  = 0x80  // Interrupt Request
    };
};
