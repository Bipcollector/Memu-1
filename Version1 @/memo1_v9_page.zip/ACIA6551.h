#pragma once
#include <cstdint>
#include <queue>
#include <string>

class ACIA6551 {
public:
    ACIA6551();
    ~ACIA6551() = default;

    uint8_t read(uint8_t reg);
    void write(uint8_t reg, uint8_t data);
    void pollKeyboard();

    [[nodiscard]] bool hasInterrupt() const {
        return (status & RDRF) && !(command & 0x02);
    }

    void injectByte(uint8_t b) {
        keyboard_buffer.push(b);
        status |= RDRF;
    }

    // Vide le buffer d'affichage vers la console Windows
    void flushDisplay();

private:
    // ---- Registres ACIA ----
    uint8_t rx_data = 0x00;
    uint8_t tx_data = 0x00;
    uint8_t status  = 0x00;
    uint8_t command = 0x00;
    uint8_t control = 0x00;
    std::queue<uint8_t> keyboard_buffer;

    enum StatusFlags : uint8_t {
        PE   = 0x01, FE   = 0x02, OVRN = 0x04,
        RDRF = 0x08, TDRE = 0x10, DCD  = 0x20,
        CTS  = 0x40, IRQ  = 0x80
    };

    // ---- Buffer de sortie (accumulé, vidé par flushDisplay) ----
    std::string display_buf;

    // ---- État de l'interpréteur Videotex ----

    // Attributs courants
    uint8_t fg_color  = 7;  // 0-7 (noir..blanc)
    uint8_t bg_color  = 0;
    bool    inverse   = false;
    bool    underline = false;

    // Jeu de caractères actif
    enum class CharSet { G0, G1, G2_NEXT };
    CharSet charset = CharSet::G0;

    // Automate d'état principal
    enum class State {
        NORMAL,      // affichage standard G0
        ESC,         // reçu ESC (0x1B)
        CSI,         // reçu ESC 0x5B -> séquence CSI ISO 6429
        SS2,         // reçu SS2 (0x19) -> prochain char = G2
        US1,         // reçu US (0x1F)  -> prochain char = rangée
        US2,         // reçu US + rangée -> prochain char = colonne
        ESC_PRO,     // séquence PRO1/PRO2/PRO3 : avaler N bytes
    };
    State   state = State::NORMAL;
    int     pro_skip = 0;   // bytes restants à avaler pour PRO1/PRO2/PRO3

    // Buffer de paramètres CSI
    std::string csi_params;   // digits + ';' accumulés
    uint8_t     us_row = 0;   // rangée lue après US

    // ---- Méthodes internes ----
    void processNormal(uint8_t b);
    void processEsc(uint8_t b);
    void processCsi(uint8_t b);
    void processSS2(uint8_t b);
    void processUS(uint8_t b);

    // Émet la séquence ANSI courante (couleurs + attributs)
    void emitAttrs();
    // Réinitialise les attributs à blanc sur noir
    void resetAttrs();

    // Convertit un caractère G1 (semi-graphique) en UTF-8 via blocs Unicode
    std::string g1ToUtf8(uint8_t b);
    // Convertit un caractère G2 (accent/symbole) en UTF-8
    std::string g2ToUtf8(uint8_t b);

    // Émet directement dans display_buf
    void emit(const std::string& s) { display_buf += s; }
    void emit(char c)               { display_buf += c; }
};
