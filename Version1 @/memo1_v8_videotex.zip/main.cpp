#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include <thread>
#include <conio.h>
#include <windows.h>
#include "Bus.h"
#include "CPU65C02.h"

// ============================================================
//  Active le mode ANSI (VT100) dans la console Windows 10+
//  Sans cela, les séquences \033[...m s'affichent en clair.
// ============================================================
static void enableAnsiConsole() {
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    if (hOut == INVALID_HANDLE_VALUE) return;
    DWORD mode = 0;
    if (!GetConsoleMode(hOut, &mode)) return;
    SetConsoleMode(hOut, mode | ENABLE_VIRTUAL_TERMINAL_PROCESSING);

    // Passer la console en UTF-8 pour les caractères semi-graphiques
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
}

// ============================================================
//  Chargement ROM interne
// ============================================================
bool loadROM(const std::string& filename, Bus& bus) {
    std::ifstream file(filename, std::ios::binary | std::ios::ate);
    if (!file.is_open()) {
        std::cerr << "[ERREUR] Impossible d'ouvrir : " << filename << "\n";
        return false;
    }
    std::streamsize size = file.tellg();
    file.seekg(0, std::ios::beg);
    if (size == 32768) {
        std::cout << "[INFO] ROM 32Ko detectee. Chargement de la 2eme moitie...\n";
        file.seekg(16384);
        file.read(reinterpret_cast<char*>(bus.getROM().data()), 16384);
    } else if (size > 0 && size <= 16384) {
        std::cout << "[INFO] ROM " << size << " octets.\n";
        file.read(reinterpret_cast<char*>(bus.getROM().data()), size);
    } else {
        std::cerr << "[ERREUR] Taille inattendue : " << size << " octets.\n";
        return false;
    }
    std::cout << "[OK] ROM interne chargee.\n";
    return true;
}

// ============================================================
//  Recherche memo1_rom.bin dans le dossier de l'exe
// ============================================================
std::string findROM() {
    char path[MAX_PATH];
    GetModuleFileNameA(NULL, path, MAX_PATH);
    std::string exe(path);
    size_t pos = exe.find_last_of("\\/");
    std::string dir = (pos != std::string::npos) ? exe.substr(0, pos + 1) : "";
    return dir + "memo1_rom.bin";
}

// ============================================================
//  Boucle d'émulation
// ============================================================
void runEmulator(Bus& bus, CPU65C02& cpu) {
    const int  CYCLES_PAR_MS = 1000;
    const auto DUREE_MS      = std::chrono::microseconds(1000);

    while (true) {
        auto t0 = std::chrono::high_resolution_clock::now();

        // Lecture clavier non-bloquante
        while (_kbhit()) {
            int ch = _getch();
            if (ch == 0 || ch == 0xE0) {
                // Touche étendue : on mappe les flèches vers les codes Minitel
                if (_kbhit()) {
                    int ext = _getch();
                    switch (ext) {
                        case 72: bus.getACIA().injectByte(0x1B);  // VT : curseur haut
                                 bus.getACIA().injectByte(0x0B); break;
                        case 80: bus.getACIA().injectByte(0x1B);  // LF : curseur bas
                                 bus.getACIA().injectByte(0x0A); break;
                        case 75: bus.getACIA().injectByte(0x1B);  // BS : curseur gauche
                                 bus.getACIA().injectByte(0x08); break;
                        case 77: bus.getACIA().injectByte(0x1B);  // HT : curseur droite
                                 bus.getACIA().injectByte(0x09); break;
                        default: break;
                    }
                }
            } else {
                bus.getACIA().injectByte(static_cast<uint8_t>(ch));
            }
        }

        // Exécution CPU
        for (int i = 0; i < CYCLES_PAR_MS; ++i) {
            cpu.irq_line = bus.getACIA().hasInterrupt();
            cpu.clock();
        }

        // Affichage
        bus.getACIA().flushDisplay();

        // Tick VIA
        bus.getVIA().tick(CYCLES_PAR_MS);

        // Synchronisation
        auto elapsed = std::chrono::high_resolution_clock::now() - t0;
        if (elapsed < DUREE_MS)
            std::this_thread::sleep_for(DUREE_MS - elapsed);
    }
}

// ============================================================
//  Point d'entrée
// ============================================================
int main(int argc, char* argv[]) {
    enableAnsiConsole();
    SetConsoleTitleA("MEMO-1 Emulator - Terminal Minitel");

    std::cout << "\033[0m";  // reset attributs ANSI
    std::cout << "========================================\n";
    std::cout << "  MEMO-1 Emulator (W65C02 @ 1MHz)\n";
    std::cout << "  Terminal Minitel Emule\n";
    std::cout << "========================================\n\n";
    std::cout.flush();

    Bus      bus;
    CPU65C02 cpu;
    cpu.connectBus(&bus);

    // Chargement ROM interne
    std::string romPath = findROM();
    if (!loadROM(romPath, bus)) {
        if (!loadROM("memo1_rom.bin", bus)) {
            std::cerr << "\n[ERREUR] memo1_rom.bin introuvable.\n";
            std::cerr << "Placez memo1_rom.bin dans le meme dossier que memo1.exe\n";
            std::cerr << "Appuyez sur Entree...";
            std::cin.get();
            return 1;
        }
    }

    // Chargement cartouche (glisser-déposer)
    if (argc >= 2) {
        std::string cartPath(argv[1]);
        bool isBin = cartPath.size() >= 4;
        if (isBin) {
            std::string ext = cartPath.substr(cartPath.size() - 4);
            for (auto& c : ext) c = static_cast<char>(tolower(c));
            isBin = (ext == ".bin");
        }
        if (!isBin) {
            std::cerr << "[AVERTISSEMENT] Pas un .bin : " << cartPath << "\n\n";
        } else if (!bus.loadCartridge(cartPath)) {
            std::cerr << "[AVERTISSEMENT] Impossible de charger : " << cartPath
                      << "\n  (8 Ko max)\n\n";
        } else {
            std::cout << "[OK] Cartouche : \"" << bus.cartridgeName() << "\"\n\n";
        }
    }

    if (bus.hasCartridge()) {
        std::cout << "[MEMO-1] Cartouche connectee -> option '4' dans le menu.\n";
    } else {
        std::cout << "[MEMO-1] Pas de cartouche. Glissez un .bin sur memo1.exe\n";
    }
    std::cout << "[SYSTEME] Boucle active. (Ctrl+C pour quitter)\n\n";
    std::cout.flush();

    cpu.reset();
    runEmulator(bus, cpu);
    return 0;
}
